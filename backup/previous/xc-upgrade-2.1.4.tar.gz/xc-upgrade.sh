#!/bin/bash

# $Rev: 400 $
# $Author: mlgantra $
# $Date: 2015-06-25 16:41:12 -0700 (Thu, 25 Jun 2015) $

# Main script to upgrade OpenXC software
# The script is tailored for included components of the upgrading package.
# Assume that there is no network connection
# and base system supports basic function such as python, apt-get

ver=2.1.4

header="OpenXCModem Software Upgrade Utility - Rev:${ver}"

function usage {
  cat <<EOU

${header}

Usage: $0 

  Upgrade utility for following components:
    xc-2.1.4.tar.gz

EOU
  exit 1
}

image=${PWD}/$1
logname=`echo $0 |sed 's/.sh//'`".log"
logfile=/var/log/$logname

filelist="$0 \
xc-2.1.4.tar.gz"


missing () {
    echo "missing $1"
    exit 1
}


main () {
    echo $header
	echo "Preparing upgrade package..."
	sleep 3

    if [ $# -gt 0 ]; then
        usage
    fi

    for f in $filelist
        do [ -f $f ] || missing $f
    done

    #
    # Handle images tarball
    #
    tmp_dir=${PWD}

	# Software directory
    main_dir=/root/OpenXCAccessory
	
	# create backup directory if needed
    # Note: 2.1.4 is factory reset version
    mkdir -p $main_dir/backup
    dlist="factory current"
    for i in $dlist
        do  backup_dir="$main_dir/backup/$i"
            rm -fr $backup_dir
            mkdir -p $backup_dir
            echo "2.1.4" > $backup_dir/upgrade.ver
            echo "xc-upgrade-2.1.4.tar.gz" >> $backup_dir/upgrade.ver
            cp -p $tmp_dir/xc-upgrade-2.1.4.tar.gz $backup_dir
        done
		
	mkdir -p $main_dir/backup/other
	other_dir=$main_dir/backup/other
	cp -p $main_dir/common/xc.conf $other_dir/xc.conf.bak
	cp -p /etc/wpa_supplicant_modem.conf $other_dir/wpa_supplicant_modem.conf.bak
	cp -p /etc/wpa_supplicant_rsu.conf $other_dir/wpa_supplicant_rsu.conf.bak
	cp -p /etc/wpa_supplicant_v2x.conf $other_dir/wpa_supplicant_v2x.conf.bak
	cp -p /etc/wpa_supplicant_v2x_top2.conf $other_dir/wpa_supplicant_v2x_top2.conf.bak

    # install code drop
    rm -fr $main_dir/common $main_dir/modem $main_dir/rsu $main_dir/startup $main_dir/v2x
	cd /
    tar xzpvf $tmp_dir/xc-2.1.4.tar.gz

    echo "system need to be rebooted to take effect ..."
    reboot
}

main $1 2>&1 | tee $logfile
