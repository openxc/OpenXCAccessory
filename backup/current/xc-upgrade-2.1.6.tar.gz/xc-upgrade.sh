#!/bin/bash

set +x

# $Rev: 400 $
# $Author: mlgantra $
# $Date: 2015-06-25 16:41:12 -0700 (Thu, 25 Jun 2015) $

# Main script to upgrade OpenXC software
# The script is tailored for included components of the upgrading package.
# Assume that there is no network connection
# and base system supports basic function such as python, apt-get

ver=2.1.6
is_factory=True

header="OpenXCModem Software Upgrade Utility - Rev:${ver}"

function usage {
  cat <<EOU

${header}

Usage: $0 

  Upgrade utility for following components:
    xc-$ver.tar.gz

EOU
  exit 1
}

#
# Handle images tarball
#
#tmp_dir=${PWD}
tmp_dir="/tmp"

image=${PWD}/$1
logname="xc-upgrade.log"
logfile=/var/log/$logname

filelist="$0 \
$tmp_dir/xc-$ver.tar.gz"

missing () {
    echo "missing $1"
    exit 1
}

main () {
    echo $header
	echo "Preparing upgrade package..."
	sleep 3

    if [ $# -gt 0 ]; then
        usage
    fi

    for f in $filelist
        do [ -f $f ] || missing $f
    done

	# Software directory
    main_dir=/root/OpenXCAccessory
	
	# create backup directory if needed
    # If this is a factory reset version put it in the factory directory
		if [ $is_factory ]; then
			backup_dir="$main_dir/backup/factory"
      rm -fr $backup_dir
      mkdir -p $backup_dir
      echo "$ver" > $backup_dir/upgrade.ver
      echo "xc-upgrade-$ver.tar.gz" >> $backup_dir/upgrade.ver
      cp -p $tmp_dir/xc-upgrade-$ver.tar.gz $backup_dir
		fi

    # install code drop
  rm -fr $main_dir/common $main_dir/modem $main_dir/rsu $main_dir/startup $main_dir/v2x $main_dir/etc $main_dir/scripts
	cd /
  tar xzpvf $tmp_dir/xc-$ver.tar.gz

}

main $1 2>&1 | tee $logfile
exit 0
